import { Controller } from '@nestjs/common';

@Controller('socket')
export class SocketController {}
